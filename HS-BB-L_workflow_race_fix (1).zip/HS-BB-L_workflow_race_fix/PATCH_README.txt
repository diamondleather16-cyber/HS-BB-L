GitHub Actions race fix

原因:
複数の Build 2025 ... ワークフローが main への push のたびに同時実行され、
master/sources.csv や output/all_matches.csv をそれぞれ更新して push 競合していた。

修正:
- build_2025_*.yml / yaml を workflow_dispatch（手動実行）のみに変更
- Commit generated data の push 前に git pull --rebase origin main を追加

使い方:
1. このZIPをCodespacesへ展開・コピー
2. python scripts/patch_workflows_manual_only.py
3. git add -A && git commit ... && git push
4. 以後は必要な Build 2025 ... を Actions から1本ずつ Run workflow
