GitHub Web版アップロード用

アップロード先:
HS-BB-L / docs /

アップロードするファイル:
app.js

GitHubのCodeタブから docs フォルダを開き、
Add file → Upload files で app.js をアップロードしてください。
同名ファイル app.js を上書きする形です。

その後 Commit changes。
