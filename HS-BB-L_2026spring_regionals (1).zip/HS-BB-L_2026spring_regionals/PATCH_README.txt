2026春季 地区大会

春の地区区分:
- 北海道
- 東北
- 関東
- 北信越
- 東海
- 近畿
- 中国
- 四国
- 九州

北海道:
2026春県階層取込時に
支部大会 = level=prefecture
全道大会本戦 = level=regional
として既に hokkaido_2026.csv に格納済み。
したがって地区大会側では複製せず既存データを参照する。

新規 regional CSV:
- 東北
- 関東
- 北信越
- 東海
- 近畿
- 中国
- 四国
- 九州

生成:
data/regionals/2026_spring/
master/collection_report_2026_spring_regionals.csv

最終検証: 9/9地区
