from pathlib import Path
import csv
import sys

EXPECTED = {
    "tohoku","kanto","hokushinetsu","tokai",
    "kinki","chugoku","shikoku","kyushu"
}

def read(path):
    with Path(path).open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def level(note):
    for p in str(note or "").split(";"):
        if p.startswith("level="):
            return p.split("=",1)[1]
    return ""

def main():
    errors = []
    folder = Path("data/regionals/2026_spring")
    found = {p.stem for p in folder.glob("*.csv")}

    if found != EXPECTED:
        errors.append(f"regional files mismatch: {sorted(found)}")

    for slug in sorted(EXPECTED):
        p = folder/f"{slug}.csv"
        if not p.exists():
            continue

        rows = read(p)
        counts = {
            rnd:sum(1 for r in rows if r.get("round")==rnd)
            for rnd in ("F","SF")
        }

        if len(rows)<7:
            errors.append(f"{slug}: rows={len(rows)}")
        if counts["F"]<1:
            errors.append(f"{slug}: F={counts['F']}")
        if counts["SF"]<2:
            errors.append(f"{slug}: SF={counts['SF']}")

        for i,r in enumerate(rows,2):
            if level(r.get("note"))!="regional":
                errors.append(f"{slug} row {i}: level not regional")
            for c in ("date","team1","score1","team2","score2","source_url","round"):
                if not str(r.get(c,"")).strip():
                    errors.append(f"{slug} row {i}: {c} blank")
            try:
                int(r["score1"]); int(r["score2"])
            except Exception:
                errors.append(f"{slug} row {i}: invalid score")

    # 北海道は既存県ファイル内のregional本戦を検証
    h = [
        r for r in read("data/01_hokkaido/hokkaido_2026.csv")
        if r.get("year")=="2026"
        and r.get("season")=="spring"
        and level(r.get("note"))=="regional"
        and "stage=main" in str(r.get("note",""))
    ]
    hc = {
        rnd:sum(1 for r in h if r.get("round")==rnd)
        for rnd in ("F","SF","QF")
    }
    if hc["F"]<1 or hc["SF"]<2 or hc["QF"]<4:
        errors.append(
            f"北海道: F={hc['F']} SF={hc['SF']} QF={hc['QF']}"
        )

    if errors:
        for e in errors[:300]:
            print("ERROR:",e)
        sys.exit(1)

    print("2026 spring regional validation OK: 9/9")

if __name__ == "__main__":
    main()
