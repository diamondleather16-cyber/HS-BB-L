from __future__ import annotations

from pathlib import Path
import csv
import re
import time
import requests
from bs4 import BeautifulSoup

BASE = "https://koshien89.com/"
YEAR = 2026
SEASON = "spring"
TIMEOUT = 30
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; HS-BB-L/1.0)"}

# 春の地区大会は9地区。
# 北海道は既に data/01_hokkaido/hokkaido_2026.csv 内で
# level=regional（全道大会本戦）として保持しているため重複登録しない。
REGIONS = [
    ("tohoku", "東北"),
    ("kanto", "関東"),
    ("hokushinetsu", "北信越"),
    ("tokai", "東海"),
    ("kinki", "近畿"),
    ("chugoku", "中国"),
    ("shikoku", "四国"),
    ("kyushu", "九州"),
]

KNOWN_URLS = {
    "kanto": "https://koshien89.com/blog-entry-3754.html",
    "hokushinetsu": "https://koshien89.com/blog-entry-3758.html",
    "tokai": "https://koshien89.com/blog-entry-3755.html",
    "kinki": "https://koshien89.com/blog-entry-3757.html",
    "shikoku": "https://koshien89.com/blog-entry-3751.html",
    "kyushu": "https://koshien89.com/blog-entry-3738.html",
}

FIELDS = [
    "year","season","region","prefecture","tournament","round","date",
    "team1","score1","team2","score2","source_url","note"
]

ROUND_MAP = {
    "決勝":"F",
    "3位決定戦":"3P",
    "5位決定戦":"5P",
    "準決勝":"SF",
    "準々決勝":"QF",
    "1回戦":"1R",
    "2回戦":"2R",
    "3回戦":"3R",
}

ROUND_RE = re.compile(
    r"^\s*※?\s*(5位決定戦|3位決定戦|準々決勝|準決勝|決勝|[1-3]回戦)"
    r"\s*\((\d{1,2})/(\d{1,2})(?:,[^)]+)?\)"
)

GAME_RE = re.compile(
    r"^[■●○]?\s*(.+?[^\d\s])\s*(\d+)(x?)\s*-\s*(\d+)(x?)\s+(.+?)(?:\((\d+)\))?$"
)

def norm(s):
    s = s.replace("\u3000"," ")
    return re.sub(r"[ \t]+"," ",s).strip()

def get(session, url):
    r = session.get(url, headers=HEADERS, timeout=TIMEOUT)
    r.raise_for_status()
    r.encoding = r.apparent_encoding or r.encoding
    return r.text

def page_title(html):
    soup = BeautifulSoup(html, "html.parser")
    return norm(soup.title.get_text(" ", strip=True)) if soup.title else ""

def discover_url(session, jp_name):
    slug = next((s for s,n in REGIONS if n==jp_name), None)
    if slug in KNOWN_URLS:
        return KNOWN_URLS[slug]

    needle = f"春季{jp_name}大会 2026"

    # 2026春地区大会の記事群は概ねこの範囲。
    for entry_id in range(3730, 3770):
        url = f"{BASE}blog-entry-{entry_id}.html"
        try:
            html = get(session, url)
        except Exception:
            continue

        title = page_title(html)
        if needle in title:
            return url

        soup = BeautifulSoup(html, "html.parser")
        head = norm(soup.get_text(" ", strip=True)[:1500])
        if needle in head:
            return url

        time.sleep(0.02)

    return None

def best_container(soup):
    candidates = []
    for el in soup.find_all(["article","main","div","section"]):
        text = el.get_text("\n", strip=True)
        markers = sum(
            text.count(k) for k in (
                "※決勝","※準決勝","※準々決勝","※1回戦","※2回戦"
            )
        )
        if markers >= 3:
            candidates.append((markers, len(text), el))

    if candidates:
        m = max(x[0] for x in candidates)
        xs = [x for x in candidates if x[0]==m]
        xs.sort(key=lambda x:x[1])
        return xs[0][2]

    return soup.body or soup

def parse_games(html, slug, jp_name, url):
    soup = BeautifulSoup(html, "html.parser")
    container = best_container(soup)

    title = re.sub(
        r"\s*\|\s*高校野球速報.*$",
        "",
        page_title(html)
    ).strip() or f"春季{jp_name}大会 2026"

    lines = [
        norm(x) for x in container.get_text("\n", strip=True).splitlines()
        if norm(x)
    ]

    rows = []
    current_round = None
    current_date = None

    for line in lines:
        rm = ROUND_RE.search(line)
        if rm:
            label, month, day = rm.groups()
            current_round = ROUND_MAP[label]
            current_date = f"{YEAR}-{int(month):02d}-{int(day):02d}"

            tail = line[rm.end():].strip()
            if tail:
                line = tail
            else:
                continue

        if not current_round or not current_date:
            continue

        if "｜" in line or "=" in line or line.startswith("(") or "本塁打" in line:
            continue

        gm = GAME_RE.match(line)
        if not gm:
            continue

        team1, s1, x1, s2, x2, team2, innings = gm.groups()

        notes = ["level=regional"]
        if x1:
            notes.append("team1_sayonara")
        if x2:
            notes.append("team2_sayonara")
        if innings:
            notes.append(f"{innings}innings")

        rows.append({
            "year":str(YEAR),
            "season":SEASON,
            "region":slug,
            "prefecture":"",
            "tournament":title,
            "round":current_round,
            "date":current_date,
            "team1":norm(team1).lstrip("■●○").strip(),
            "score1":s1,
            "team2":norm(team2),
            "score2":s2,
            "source_url":url,
            "note":";".join(notes),
        })

    seen = set()
    unique = []
    for r in rows:
        key = (
            r["date"],r["round"],r["team1"],r["score1"],
            r["team2"],r["score2"]
        )
        if key not in seen:
            seen.add(key)
            unique.append(r)

    return unique, title

def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)

def read_rows(path):
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def level(note):
    for p in str(note or "").split(";"):
        if p.startswith("level="):
            return p.split("=",1)[1]
    return ""

def hokkaido_existing_report():
    path = Path("data/01_hokkaido/hokkaido_2026.csv")
    rows = [
        r for r in read_rows(path)
        if r.get("year")=="2026"
        and r.get("season")=="spring"
        and level(r.get("note"))=="regional"
        and "stage=main" in str(r.get("note",""))
    ]

    counts = {
        rnd:sum(1 for r in rows if r.get("round")==rnd)
        for rnd in ("F","SF","QF")
    }

    status = "OK" if (
        counts["F"]>=1 and counts["SF"]>=2 and counts["QF"]>=4
    ) else "CHECK"

    return {
        "region":"北海道",
        "article_url":rows[0]["source_url"] if rows else "",
        "match_count":len(rows),
        "F":counts["F"],
        "SF":counts["SF"],
        "QF":counts["QF"],
        "status":status,
        "note":"全道大会本戦は既存 hokkaido_2026.csv の level=regional を参照",
    }

def main():
    session = requests.Session()
    out_dir = Path("data/regionals/2026_spring")

    report = [hokkaido_existing_report()]
    failures = []

    if report[0]["status"] != "OK":
        failures.append("北海道: existing all-Hokkaido regional data incomplete")

    for slug, jp_name in REGIONS:
        print(f"[{jp_name}] locating article...", flush=True)
        url = discover_url(session, jp_name)

        if not url:
            report.append({
                "region":jp_name,"article_url":"","match_count":0,
                "F":0,"SF":0,"QF":0,"status":"MISSING_ARTICLE","note":""
            })
            failures.append(f"{jp_name}: article not found")
            continue

        try:
            html = get(session, url)
            rows, title = parse_games(html, slug, jp_name, url)
        except Exception as e:
            rows = []
            title = f"春季{jp_name}大会 2026"
            failures.append(f"{jp_name}: fetch/parse error {e}")

        counts = {
            rnd:sum(1 for r in rows if r["round"]==rnd)
            for rnd in ("F","SF","QF")
        }

        # 8校大会などはQF見出しではなく1回戦4試合の場合があるため、
        # 基本の完結性は「F=1 / SF=2 / 総試合>=7」。
        status = "OK" if (
            len(rows)>=7
            and counts["F"]>=1
            and counts["SF"]>=2
        ) else "CHECK"

        if status != "OK":
            failures.append(
                f"{jp_name}: matches={len(rows)} "
                f"F={counts['F']} SF={counts['SF']} QF={counts['QF']}"
            )

        write_csv(out_dir/f"{slug}.csv", rows)

        report.append({
            "region":jp_name,
            "article_url":url,
            "match_count":len(rows),
            "F":counts["F"],
            "SF":counts["SF"],
            "QF":counts["QF"],
            "status":status,
            "note":title,
        })

        print(
            f"  {status}: matches={len(rows)} "
            f"F={counts['F']} SF={counts['SF']} QF={counts['QF']} "
            f"{url}",
            flush=True
        )

    rp = Path("master/collection_report_2026_spring_regionals.csv")
    fields = ["region","article_url","match_count","F","SF","QF","status","note"]
    with rp.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(report)

    ok = sum(1 for r in report if r["status"]=="OK")
    print(f"\nRegional coverage: {ok}/9")

    if failures:
        print("\nNeeds check:")
        for x in failures:
            print(" -", x)
        raise SystemExit(2)

if __name__ == "__main__":
    main()
