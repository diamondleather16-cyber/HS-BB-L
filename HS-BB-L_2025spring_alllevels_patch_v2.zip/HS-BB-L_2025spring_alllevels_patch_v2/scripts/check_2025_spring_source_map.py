from pathlib import Path
import csv, sys

p = Path("master/collection_report_2025_spring.csv")
if not p.exists():
    print("ERROR: master/collection_report_2025_spring.csv not found")
    sys.exit(1)

with p.open("r", encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))

usable = [r for r in rows if (r.get("prefecture") or "").strip() and ((r.get("article_url") or r.get("source_url") or "").strip())]
print(f"previous spring source map: {len(usable)}/47")
if len(usable) != 47:
    sys.exit(1)
