2025春 All Levels 修正 v2

原因:
- 前版は47都道府県ごとにカテゴリページを探索し、短時間に大量アクセスしていた。
- 手動再実行時に記事探索がほぼ全県で article not found になった。

修正:
1. すでに47/47で成功済みの
   master/collection_report_2025_spring.csv
   に保存された各県の article_url を再利用。
2. 47県の記事ページだけを取得する。
3. 「※地区予選(5/3)」「※支部予選(...)」などを
   level=... + round=QUAL として正しく取り込む。
4. workflowは手動実行のみ。
5. push前に git pull --rebase origin main を実行。
